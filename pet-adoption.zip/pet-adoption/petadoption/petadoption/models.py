from django.db import models

class Pet(models.Model):
    pet_name = models.CharField(max_length=100)
    no_of_pets = models.IntegerField()
    description = models.TextField()
    
    class Meta:
        db_table = 'pet'


class EmpInsert(models.Model):
    name=models.CharField(max_length=100)
    email=models.CharField(max_length=100)
    phone=models.CharField(max_length=11)
    address=models.CharField(max_length=255)
    password=models.CharField(max_length=10)

    class Meta:
        db_table="registration"
    class params:
        db = 'default'


