# views.py
from django.contrib.auth import authenticate, login
from django.contrib import messages
from django.shortcuts import render, redirect
from django.http import HttpResponse
from .models import EmpInsert, Pet  # Make sure to import the Pet model
from .models import Pet



def home(request):
    return render(request, 'index.html')

def aboutus(request):
    return render(request, 'about-us.html')

def contact(request):
    return render(request, 'contacts.html')

def adoption(request):
    return render(request, 'blog.html')

def adminlogin(request):
    return render(request, 'login.html')

def register(request):
    return render(request, 'register.html')

def services(request):
    return render(request, 'services.html')
    
def pets(request):
    return render(request, 'pets.html')

def addpet(request):
    if request.method == "POST":
        new_pet = Pet()
        new_pet.pet_name = request.POST.get('pet_name')
        new_pet.category_id = request.POST.get('category')
        new_pet.no_of_pets = request.POST.get('pet_count')
        new_pet.description = request.POST.get('description')

        new_pet.save()
        messages.success(request, 'Pet details saved successfully!')
        return redirect('addpet')  # Redirect to the same page after saving
    else:
        return render(request, 'addpet.html')

def Insertrecord(request):
    if request.method == "POST":
        saverecord = EmpInsert()
        saverecord.name = request.POST.get('name')
        saverecord.email = request.POST.get('email')
        saverecord.phone = request.POST.get('phone')
        saverecord.address = request.POST.get('address')
        saverecord.password = request.POST.get('password')  # this password is not working
        saverecord.save()
        messages.success(request, 'Record saved')
        return render(request, 'register.html')
    else:
        return render(request, 'register.html')

def login_view(request):
    print("Login view called")
    if request.method == 'POST':
        name = request.POST['name']
        password = request.POST['password']

        user = authenticate(request, name=name, password=password)

        if user is not None:
            login(request, user)
            messages.success(request, 'Login successful!')
            return redirect('blog.html')
        else:
            messages.error(request, 'Invalid username or password.')
            return render(request, 'login.html')

    return render(request, 'login.html')

def fetch_pet_data(request):
    pets = Pet.objects.values('pet_name', 'no_of_pets', 'description')
    return render(request, 'fetch_pets.html', {'pets': pets})