create database petadoption;

use petadoption;
 
-- Create registration table
CREATE TABLE registration (
    registration_id INT PRIMARY KEY AUTOINCREMENT,
    name VARCHAR(255) NOT NULL,
    address VARCHAR(255),
    phone VARCHAR(15) NOT NULL,
    email VARCHAR(255) NOT NULL,
    password VARCHAR(255) NOT NULL
);

-- Create category table
CREATE TABLE category (
    category_id INT PRIMARY KEY AUTOINCREMENT,
    category_name VARCHAR(255) NOT NULL
);

-- Create pet table with additional columns
CREATE TABLE pet (
    pet_id INT PRIMARY KEY AUTOINCREMENT,
    pet_name VARCHAR(255),
    no_of_pets INT,
    pet_image VARCHAR(255),
    description VARCHAR(255),
    category_id INT,
    FOREIGN KEY (category_id) REFERENCES category(category_id)
);